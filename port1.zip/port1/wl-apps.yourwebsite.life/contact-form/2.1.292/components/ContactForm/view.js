!(function (e, t) {
  if ("object" == typeof exports && "object" == typeof module)
    module.exports = t();
  else if ("function" == typeof define && define.amd) define([], t);
  else {
    var n = t();
    for (var r in n) ("object" == typeof exports ? exports : e)[r] = n[r];
  }
})(window, function () {
  return (function (e) {
    function t(t) {
      for (var n, r, a = t[0], i = t[1], c = 0, u = []; c < a.length; c++)
        (r = a[c]),
          Object.prototype.hasOwnProperty.call(o, r) && o[r] && u.push(o[r][0]),
          (o[r] = 0);
      for (n in i) Object.prototype.hasOwnProperty.call(i, n) && (e[n] = i[n]);
      for (s && s(t); u.length; ) u.shift()();
    }
    var n = {},
      r = { main: 0 },
      o = { main: 0 };
    function a(t) {
      if (n[t]) return n[t].exports;
      var r = (n[t] = { i: t, l: !1, exports: {} });
      return e[t].call(r.exports, r, r.exports, a), (r.l = !0), r.exports;
    }
    (a.e = function (e) {
      var t = [];
      r[e]
        ? t.push(r[e])
        : 0 !== r[e] &&
          { "contact-form-chunk": 1 }[e] &&
          t.push(
            (r[e] = new Promise(function (t, n) {
              for (
                var o = e + ".view.css",
                  i = a.p + o,
                  c = document.getElementsByTagName("link"),
                  u = 0;
                u < c.length;
                u++
              ) {
                var s =
                  (l = c[u]).getAttribute("data-href") ||
                  l.getAttribute("href");
                if ("stylesheet" === l.rel && (s === o || s === i)) return t();
              }
              var f = document.getElementsByTagName("style");
              for (u = 0; u < f.length; u++) {
                var l;
                if ((s = (l = f[u]).getAttribute("data-href")) === o || s === i)
                  return t();
              }
              var d = document.createElement("link");
              (d.rel = "stylesheet"),
                (d.type = "text/css"),
                (d.onload = t),
                (d.onerror = function (t) {
                  var o = (t && t.target && t.target.src) || i,
                    a = new Error(
                      "Loading CSS chunk " + e + " failed.\n(" + o + ")"
                    );
                  (a.code = "CSS_CHUNK_LOAD_FAILED"),
                    (a.request = o),
                    delete r[e],
                    d.parentNode.removeChild(d),
                    n(a);
                }),
                (d.href = i),
                document.getElementsByTagName("head")[0].appendChild(d);
            }).then(function () {
              r[e] = 0;
            }))
          );
      var n = o[e];
      if (0 !== n)
        if (n) t.push(n[2]);
        else {
          var i = new Promise(function (t, r) {
            n = o[e] = [t, r];
          });
          t.push((n[2] = i));
          var c,
            u = document.createElement("script");
          (u.charset = "utf-8"),
            (u.timeout = 120),
            a.nc && u.setAttribute("nonce", a.nc),
            (u.src = (function (e) {
              return (
                a.p +
                "" +
                ({
                  "vendors~contact-form-chunk": "vendors~contact-form-chunk",
                  "contact-form-chunk": "contact-form-chunk",
                }[e] || e) +
                ".js"
              );
            })(e));
          var s = new Error();
          c = function (t) {
            (u.onerror = u.onload = null), clearTimeout(f);
            var n = o[e];
            if (0 !== n) {
              if (n) {
                var r = t && ("load" === t.type ? "missing" : t.type),
                  a = t && t.target && t.target.src;
                (s.message =
                  "Loading chunk " + e + " failed.\n(" + r + ": " + a + ")"),
                  (s.name = "ChunkLoadError"),
                  (s.type = r),
                  (s.request = a),
                  n[1](s);
              }
              o[e] = void 0;
            }
          };
          var f = setTimeout(function () {
            c({ type: "timeout", target: u });
          }, 12e4);
          (u.onerror = u.onload = c), document.head.appendChild(u);
        }
      return Promise.all(t);
    }),
      (a.m = e),
      (a.c = n),
      (a.d = function (e, t, n) {
        a.o(e, t) || Object.defineProperty(e, t, { enumerable: !0, get: n });
      }),
      (a.r = function (e) {
        "undefined" != typeof Symbol &&
          Symbol.toStringTag &&
          Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
          Object.defineProperty(e, "__esModule", { value: !0 });
      }),
      (a.t = function (e, t) {
        if ((1 & t && (e = a(e)), 8 & t)) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var n = Object.create(null);
        if (
          (a.r(n),
          Object.defineProperty(n, "default", { enumerable: !0, value: e }),
          2 & t && "string" != typeof e)
        )
          for (var r in e)
            a.d(
              n,
              r,
              function (t) {
                return e[t];
              }.bind(null, r)
            );
        return n;
      }),
      (a.n = function (e) {
        var t =
          e && e.__esModule
            ? function () {
                return e.default;
              }
            : function () {
                return e;
              };
        return a.d(t, "a", t), t;
      }),
      (a.o = function (e, t) {
        return Object.prototype.hasOwnProperty.call(e, t);
      }),
      (a.p =
        "https://wl-apps.yourwebsite.life/contact-form/2.1.292/components/ContactForm/"),
      (a.oe = function (e) {
        throw (console.error(e), e);
      }),
      (a.h = "99e45a6e7d84f9444b63"),
      (a.cn = "main");
    var i = (window.webpackJsonp = window.webpackJsonp || []),
      c = i.push.bind(i);
    (i.push = t), (i = i.slice());
    for (var u = 0; u < i.length; u++) t(i[u]);
    var s = c;
    return a((a.s = "./src/editor/view.js"));
  })({
    "./src/editor/view.js": function (e, t, n) {
      (function (e) {
        function t() {
          return (t =
            Object.assign ||
            function (e) {
              for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                for (var r in n)
                  Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
              }
              return e;
            }).apply(this, arguments);
        }
        var r = { ContactForm: null },
          o = function (e) {
            var t =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : 100,
              n =
                arguments.length > 2 && void 0 !== arguments[2]
                  ? arguments[2]
                  : 3e4;
            return new Promise(function (r, o) {
              var a,
                i = new Date();
              a = setTimeout(function c() {
                if (e()) return clearTimeout(a), void r();
                +new Date() - i > n ? o() : (a = setTimeout(c, t));
              }, t);
            });
          },
          a = function (e) {
            var t = {};
            if (e.hasAttributes())
              for (var n = e.attributes, r = n.length - 1; r >= 0; r--) {
                var o = n[r],
                  a = o.name,
                  i = o.value;
                t[a] = i;
              }
            return t;
          },
          i = null;
        i = new IntersectionObserver(
          function (n) {
            n.forEach(function (n) {
              if (n.isIntersecting) {
                var c = n.target;
                i.unobserve(c),
                  o(function () {
                    return r.ContactForm;
                  }).then(function () {
                    return (function (n) {
                      var o = n.dataset,
                        i = o.hydrate;
                      if (!o.rendered)
                        try {
                          var c = JSON.parse(i);
                          if (c.iconEnabled) {
                            var u = n.querySelector("[data-role=icon]");
                            u &&
                              Object.assign(c, {
                                iconHtml: u.innerHTML,
                                iconAttributes: a(u),
                              });
                          }
                          var s = n.querySelector(
                              '[data-role="success-message"]'
                            ),
                            f = n.querySelector('[data-role="error-message"]'),
                            l = s.innerHTML || "",
                            d = f.innerHTML || "",
                            p = r.ContactForm;
                          window.ReactDOM.hydrate(
                            e.createElement(
                              p,
                              t({}, c, { successMessage: l, errorMessage: d })
                            ),
                            n
                          ),
                            (n.dataset.rendered = !0);
                        } catch (e) {
                          console.error(e);
                        }
                    })(c);
                  });
              }
            });
          },
          { rootMargin: "100px" }
        );
        var c = function (e) {
          for (
            var t = e.querySelectorAll("[data-app=contact-form]"), n = 0;
            n < t.length;
            ++n
          ) {
            var r = t[n];
            i.observe(r);
          }
        };
        o(function () {
          return window.loadReactDOM;
        })
          .then(window.loadReactDOM)
          .then(function () {
            return Promise.all([
              n.e("vendors~contact-form-chunk"),
              n.e("contact-form-chunk"),
            ]).then(n.bind(null, "./src/editor/chunk.js"));
          })
          .then(function (e) {
            (r.ContactForm = e.ContactForm), c(document);
          }),
          o(function () {
            return window.registerAppComponentInitializer;
          })
            .then(function () {
              return window.registerAppComponentInitializer(c);
            })
            .catch(function () {
              return console.log(
                "window.registerAppComponentInitializer not found"
              );
            });
      }).call(this, n("react"));
    },
    react: function (e, t) {
      e.exports = React;
    },
    "react-dom": function (e, t) {
      e.exports = ReactDOM;
    },
  });
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmlldy5qcyIsInNvdXJjZXMiOlsid2VicGFjazovLy92aWV3LmpzIl0sIm1hcHBpbmdzIjoiQUFBQSIsInNvdXJjZVJvb3QiOiIifQ==
